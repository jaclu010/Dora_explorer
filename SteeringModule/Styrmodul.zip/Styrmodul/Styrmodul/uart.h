﻿/*
 * uart.h
 *
 * Created: 11/10/2016 11:25:47 AM
 *  Author: freis685
 */ 


#ifndef UART_H_
#define UART_H_

#define F_CPU 14745600

void uart_init();
void uart_send();
void uart_receive();

#endif /* UART_H_ */