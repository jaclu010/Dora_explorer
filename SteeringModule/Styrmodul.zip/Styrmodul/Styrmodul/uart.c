﻿/*
 * CFile1.c
 *
 * Created: 11/10/2016 11:12:07 AM
 *  Author: freis685
 */ 

#include <avr/io.h>
#include "uart.h"

void uart_init() {
	unsigned int baud = 15;
	UBRR0 = 0;
	
	// Port 0, UART
	UCSR0A |= (1 << U2X0); // Double transmission rate
	UCSR0B |= (1 << RXEN0)|(1 << TXEN0)|(1<<RXCIE0); // Enables receive, transmit and receive interrupt
	
	UBRR0 = baud; //
}

void uart_send() {
	
}