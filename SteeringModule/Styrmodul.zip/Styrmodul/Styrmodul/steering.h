﻿/*
 * steering.h
 *
 * Created: 11/10/2016 11:23:10 AM
 *  Author: freis685
 */ 


#ifndef STEERING_H_
#define STEERING_H_

#define F_CPU 14745600

#define LEFT_SPEED OCR0A
#define RIGHT_SPEED OCR0B
#define LASER_SPEED OCR1A

#define LEFT PORTA0
#define RIGHT PORTA1

#define FORWARD 1
#define BACKWARD 0
#define BOTH 2

void init_motors();
void set_wheel_dir(uint8_t dir, uint8_t side);

#endif /* STEERING_H_ */