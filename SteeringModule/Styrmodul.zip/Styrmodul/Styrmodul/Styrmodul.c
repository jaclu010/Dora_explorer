/*
 * Styrmodul.c
 *
 * Created: 11/9/2016 8:46:41 AM
 *  Author: freis685
 */ 

#define F_CPU 14745600

#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>
#include <stdbool.h>

#include "steering.h"
#include "uart.h"

typedef enum {LEFT_SIDE, RIGHT_SIDE, BOTH_SIDES, TOWER, NONE} sideState;

bool read_speed = false;
sideState side = NONE;
//uint8_t startBytes = 0;

ISR(USART0_RX_vect) {
	char rec_byte = UDR0;


	if (read_speed) {
		switch (side) {
			case LEFT_SIDE:
				LEFT_SPEED = rec_byte;
				break;
			case RIGHT_SIDE:
				RIGHT_SPEED = rec_byte;
				break;
			case TOWER:
				LASER_SPEED = rec_byte;
				break;
			case BOTH_SIDES:
				LEFT_SPEED = rec_byte;
				RIGHT_SPEED = rec_byte;
				break;
			default:
				break;
		}	
		side = NONE;
		read_speed = false;
	} else {
		switch (rec_byte) {
			case 'f':
				set_wheel_dir(FORWARD,BOTH);
				break;
			case 'b':
				set_wheel_dir(BACKWARD,BOTH);
				break;
			case 'l':
				set_wheel_dir(FORWARD,RIGHT);
				set_wheel_dir(BACKWARD,LEFT);
				break;
			case 'r':
				set_wheel_dir(FORWARD,LEFT);
				set_wheel_dir(BACKWARD,RIGHT);
				break;
			case 's':
				side = BOTH_SIDES;
				read_speed = true;
				break;
			case 'v':
				side = LEFT_SIDE;
				read_speed = true;
				break;
			case 'h':
				side = RIGHT_SIDE;
				read_speed = true;
				break;
			case 't':
				side = TOWER;
				read_speed = true;
				break;
		}
	}
}

int main(void) {
	init_motors();
	
	LEFT_SPEED = 0; // LEFT
	RIGHT_SPEED = 0; // RIGHT
	
	LASER_SPEED = 80;
	
	uart_init();
	sei();	// enable interrupts
	
    while(1) {		
    }
}